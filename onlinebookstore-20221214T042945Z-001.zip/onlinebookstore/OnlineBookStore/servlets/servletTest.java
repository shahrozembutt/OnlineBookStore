package servlets;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.Before;

import java.util.logging.Logger;

public class servletTest{
    
    
    double total;
    double amount;
    int quantity;
    int bQty;
    
@Test
public void checkTotal() {
    total = amount + total;
    total = 10 + 5;
    assertEquals("Are the same" , 15 , total , 0.001 );
    System.out.println("checkTotal test case has passed.");
}
    
@Test
public void checkAmount() {
    amount = quantity + total;
    amount = 10 + 15;
    assertEquals("This is the current amount" , 25 , amount, 0.002);
    System.out.println("checkAmount test case has passed.");
    
}

@Test 
public void bookQuantityCheck() {
    bQty = bQty - quantity;
    assertSame("This is the book quantity" ,quantity , bQty);
    System.out.println("bookQuantityCheck test case has passed.");
    
    
}

}