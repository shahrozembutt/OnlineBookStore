package servlets;


import static org.junit.jupiter.api.Assertions.*;

mport org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

// Currently being updated

@RunWith(MockitoJUnitRunner.class)

class userTesting {

	@Mock
	private jdbcTemplate jdbcTemplateMock;
	
	@InjectMocks
	private RegistrationService service;
	
	@Test
	public void testNewUser() {
		User user = new User("namer", "123", "whbqd", "wdhhb", "1435 drive", "2374938490", "something@gmail.com");
		boolean registered = service.register(user);
		
		assertThat(registered, is(true));
		verify(jdbcTemplateMock).update(
				anyString(), 
				eq(getUsername()),
				eq(getPassword()),
				eq(getFirstname()),
				eq(getLastname()),
				eq(getAddress()),
				eq(getPhone()),
				eq(getMailid()));		
	}
	
	@Test
	
	public void testUserExists() {
		return;
	}
}
